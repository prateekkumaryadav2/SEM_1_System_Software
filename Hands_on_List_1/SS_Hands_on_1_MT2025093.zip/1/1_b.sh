ln dummy.txt hard_link_1;

# chmod +x 1_b.sh
# make the file executable

# ./1_b.sh
# execute the file

# ls -l hardlink2
# view links