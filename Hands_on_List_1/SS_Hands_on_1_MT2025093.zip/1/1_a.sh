ln -s dummy.txt soft_link_1;

# chmod +x 1_shell_a.sh
# make the file executable

# ./1_a.sh
# execute the file

# ls -l
# view links

# lrwxr-xr-x@ 1 prateek  staff  9 Sep  3 19:01 soft_link_1 -> dummy.txt