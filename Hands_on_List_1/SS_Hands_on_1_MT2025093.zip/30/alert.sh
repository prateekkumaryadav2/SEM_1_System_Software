echo "hey there"
# echo "i arrived on time at 10:00"